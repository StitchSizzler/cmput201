#ifndef JOHNSON_H
#define JOHNSON_H
#endif

int johnson(int set_jobs[][3], int num_mac, int t, int j2[]);
