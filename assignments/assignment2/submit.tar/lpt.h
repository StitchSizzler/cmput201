#ifndef LPT_H
#define LPT_H
#endif

int lpt(int set_jobs[], int num_mac, int num_jobs, int t, int j1[]);
