- Questions 5, 6, and 8 from pages 34-45 are named
  q5.c, q6.c, q8.c respectively.

- Question 5 from pages 51-52 is named q5b.c

- To compile programs, type
  gcc -Wall -std-c99 <file_name> -o <new_name(optional)>
