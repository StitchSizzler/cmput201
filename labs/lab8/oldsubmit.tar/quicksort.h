#ifndef QUICKSORT_H
#define QUICKSORT_H

void quicksort(int a[], int low, int high);
int split(int a[], int low, int high);

