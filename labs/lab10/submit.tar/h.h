#ifndef H_H
#define H_H
#endif


void heapify(int to_sort[], int len, int x, int *count);

void heap_sort(int to_sort[], int len, int *count);
