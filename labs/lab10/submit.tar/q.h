#ifndef Q_H
#define Q_H
#endif


int partition (int to_sort[], int low, int high, int *count);


void quick_sort(int to_sort[], int low, int high, int *count);
