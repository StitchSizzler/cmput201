#ifndef SORTING_H
#define SORTING_H
#endif


#include <stdio.h>
#include <string.h>
#include "b.h"
#include "s.h"
#include "h.h"
#include "q.h"
#include "m.h"
#include "i.h"
