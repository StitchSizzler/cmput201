#ifndef S_H
#define S_H
#endif


void selection_sort(int to_sort[], int len, int *count);
