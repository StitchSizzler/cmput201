#ifndef B_H
#define B_H
#endif


void bubble_sort(int to_sort[], int len, int *count);
