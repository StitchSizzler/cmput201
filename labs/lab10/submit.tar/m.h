#ifndef M_H
#define M_H
#endif


void merge_sort(int to_sort[], int left, int right, int *count);
